#!/usr/bin/env python

# The Keyboard Controller Node for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials

# This controller extends the base DroneVideoDisplay class, adding a keypress handler to enable keyboard control of the drone

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib
import rospy
import time
import numpy as np
import cv2
import cv2 as cv

#*********************************************************************************************************
from simple_pid import PID
pid_X=PID(1,0.0,0.0,setpoint=0,output_limits=(-0.5, +0.5))
pid_Z=PID(1,0,0.0,setpoint=0,output_limits=(-0.5, +0.5))
# Load the DroneController class, which handles interactions with the drone, and the DroneVideoDisplay class, which handles video display
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import CompressedImage
from geometry_msgs.msg import Twist
#Line_detection_object=None

class Circle_detection:
	def __init__(self):
		self.calibrate=True
		self.calibrateY=True
		self.firsttime=True
#***********************************************************************************************
		self.bridge = CvBridge()
		self.subVideo = rospy.Subscriber('/bebop/image_raw/compressed', CompressedImage, self.visionCycle)
		self.cutwidth=50
		self.flag_perspective=False
#**********************************************************************************************
		self.running = rospy.get_param("F_running")
		self.max_speed_go=rospy.get_param("maxspeed_go")
		self.bound=0.3
		self.boundp=rospy.get_param("boundp")
		pid_X.Kp=rospy.get_param("P_X")
		pid_X.Kd=rospy.get_param("D_X")
		pid_X.Ki=rospy.get_param("I_X")
		pid_Z.Kp=rospy.get_param("P_Z")
		pid_Z.Kp=rospy.get_param("D_Z")
		pid_Z.Kp=rospy.get_param("I_Z")
		self.printing=True
		self.pub = rospy.Publisher('Send_X_Z_controller_out', Twist, queue_size=10)
		self.command=Twist()
		rospy.spin()
#*******************************************************************************************************
	def nothing(self,a):
		pass
#******************************************************************************************************
	def Getrosparam(self):
		self.running = rospy.get_param("F_running")
		self.max_speed_go=rospy.get_param("maxspeed_go")
		self.boundp=rospy.get_param("boundp")
		pid_X.Kp=rospy.get_param("P_X")
		pid_X.Kd=rospy.get_param("D_X")
		#pid_X.Ki=rospy.get_param("I_X")
		pid_Z.Kp=rospy.get_param("P_Z")
		pid_Z.Kp=rospy.get_param("D_Z")
		#pid_Z.Kp=rospy.get_param("I_Z")
		self.bound=rospy.get_param("boundX")
		pid_X.output_limits=(-self.bound,self.bound)
		self.bound=rospy.get_param("boundZ")
		pid_Z.output_limits=(-self.bound,self.bound)
#****************************************************************************************************		
# We add a keyboard handler to the DroneVideoDisplay to react to keypresses
	def visionCycle(self, data):
    		try:
    			cv_image = self.bridge.compressed_imgmsg_to_cv2(data, "bgr8")
       		except CvBridgeError as e:
          		print(e)
		(hh,ww,channels) = cv_image.shape
#***************************************************************************************************
		if(self.firsttime==True):
			h_low = 0
        		s_low = 0
       			v_low = 0
    			h_high =0
    			s_high =0
        		v_high =0	
			self.firsttime=False	
			if (self.calibrate==True):
	       			cv2.imshow('Trackbar Circle', np.zeros((1, 512, 3), np.uint8))
				cv2.namedWindow('Trackbar Circle')
	       			# create trackbars for color change		
	       			cv2.createTrackbar('H_high', 'Trackbar Circle', 0, 255, self.nothing)
	       			cv2.createTrackbar('S_high', 'Trackbar Circle', 0, 255, self.nothing)
	       			cv2.createTrackbar('V_high', 'Trackbar Circle', 0, 255,self.nothing)
				cv2.createTrackbar('H_low', 'Trackbar Circle', 0, 255, self.nothing)
				cv2.createTrackbar('S_low', 'Trackbar Circle', 0, 255, self.nothing)
				cv2.createTrackbar('V_low', 'Trackbar Circle', 0, 255, self.nothing)
				cv2.waitKey(10)	#//////////////////////////////////////////////////////////////////////////////////////////////////////////
				fh = open("/home/avjf/ali_ros_projects/src/bebop/src/circle_color_calibrate.txt", "r")
				self.HIGH=[0,0,0]
				self.LOW=[0,0,0]
				i=0
				data=fh.readlines()
				for line in data:
    					if(i<=2):
        					self.LOW[i]=int(line)
    					else:
        					self.HIGH[i-3]=int(line)
    					i=i+1
				fh.close()
				if (self.calibrate==True):
					cv2.setTrackbarPos('H_high', 'Trackbar Circle',self. HIGH[0])
					cv2.setTrackbarPos('S_high', 'Trackbar Circle',self. HIGH[1])
	    				cv2.setTrackbarPos('V_high', 'Trackbar Circle', self.HIGH[2])
					cv2.setTrackbarPos('H_low', 'Trackbar Circle',self. LOW[0])
					cv2.setTrackbarPos('S_low', 'Trackbar Circle', self.LOW[1])
					cv2.setTrackbarPos('V_low', 'Trackbar Circle', self.LOW[2])
#****************************************************************************************************
		circle=cv2.GaussianBlur(cv_image,(5,5),0)
		circle = cv2.cvtColor(circle, cv2.COLOR_RGB2HSV)
#/////////////////////////////////////////////////////////////////////////////////////////
		if(self.calibrate==True):
       			h_low = cv2.getTrackbarPos('H_low', 'Trackbar Circle')
        		s_low = cv2.getTrackbarPos('S_low', 'Trackbar Circle')
       			v_low = cv2.getTrackbarPos('V_low', 'Trackbar Circle')
    			h_high = cv2.getTrackbarPos('H_high', 'Trackbar Circle')
    			s_high = cv2.getTrackbarPos('S_high', 'Trackbar Circle')
        		v_high = cv2.getTrackbarPos('V_high', 'Trackbar Circle')
			fh = open("/home/avjf/ali_ros_projects/src/bebop/src/circle_color_calibrate.txt", "w")
			fh.write(str(h_low))
			fh.write("\n"+str(s_low))
			fh.write("\n"+str(v_low))
			fh.write("\n"+str(h_high))
			fh.write("\n"+str(s_high))
			fh.write("\n"+str(v_high))
			fh.close()	
#/////////////////////////////////////////////////////////////////////////////////////////////////////
		else:
       			h_low = self.LOW[0]
        		s_low = self.LOW[1]
       			v_low = self.LOW[2]
    			h_high = self.HIGH[0]
    			s_high = self.HIGH[2]
        		v_high =self.HIGH[2]		

#//////////////////////////////////////////////////////////////////////////////////////
		lower = np.array([86,115,0])#[90,90,181])
		upper = np.array([177,255,255])#107 ,232,255])
#///////////////////////////////////////////////////////////////////////////////////////////////	
		circle_mask = cv2.inRange(circle, lower, upper)
		circle_mask= cv2.bitwise_and(circle,circle, mask= circle_mask)
		lower_R = np.array([h_low,s_low,v_low])
		upper_R = np.array([h_high ,s_high,v_high])
		circle_mask= cv2.inRange(circle_mask, lower_R, upper_R)
#/////////////////////////////////////////////////////////////////////////////////////////////////
		if(self.calibrate==True):
			cv2.imshow('circle_mask', circle_mask)
			cv2.waitKey(1)	
		_ff, contoursW, hierarchyW = cv2.findContours(circle_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		if len(contoursW) > 0 :
			cnt = max(contoursW, key = cv2.contourArea)
			M = cv2.moments(cnt)
			if M['m00'] != 0:
				(x, z), radius = cv2.minEnclosingCircle(cnt)
           			R= radius
            			center = (int(x), int(z))
            			radius = int(radius)
				print('circle yes')
           			cv_image = cv2.circle(cv_image, center, radius, (0, 255, 0), 2)
				Z_in=z-hh
				X_in=x-ww
           			#print('X: '+str(X_in)+' Z :'+str(Z_in)+' R: '+str(R))
				if(R>20):
					self.Getrosparam()
					Z_out=pid_Z(Z_in)
					X_out=pid_X(X_in)
					self.command.angular.y=X_out
					self.command.linear.z=Z_out
					self.pub.publish(self.command)
		if(self.calibrate==False):
			cv2.imshow('circle_image', cv_image)
			cv2.waitKey(1)
#*****************************************************************************************************
	def findMaxContour(self, contours,id):
		if len(contours) > 0 :
			cnt = max(contours, key = cv2.contourArea)
			M = cv2.moments(cnt)
			if M['m00'] != 0:
				cx = int(M['m10']/M['m00'])
				cy = int(M['m01']/M['m00'])
				return [cx, cy, cv2.contourArea(cnt),id]
			else :
				return [0, 0, 0,-1]
				
		else :
			return [0, 0, 0,-1]
		
#****************************************************************************************************
# Setup the application
if __name__=='__main__':
	rospy.init_node('Circle_1')
	circle_detection_object=Circle_detection()
	rospy.signal_shutdown('Great Flying!')
	

