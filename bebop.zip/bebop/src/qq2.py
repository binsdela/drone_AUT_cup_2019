#!/usr/bin/env python

# The Keyboard Controller Node for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials

# This controller extends the base DroneVideoDisplay class, adding a keypress handler to enable keyboard control of the drone

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies


from pyzbar.pyzbar import decode

import cv2
import numpy as np

cap = cv2.VideoCapture(0)
cv2.namedWindow('frame')

while(cap.isOpened()):
    ret, frame = cap.read()
    if ret==True:
        decodedData = decode(frame)
        # decodedData.decode
        for index in decodedData :
        	print(index.polygon)
        	cv2.circle(frame,index.polygon[0], 10, (0,0,255), -1)
        cv2.imshow('frame',frame)
        c = cv2.waitKey(1)
        if c == ord('q') or c == 27:
            break
    else:
        break

# Release everything if job is finished
cap.release()
cv2.destroyAllWindows()