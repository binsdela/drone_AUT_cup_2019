
import roslib
import rospy
import time
import numpy as np
import cv2

from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image
#'optional' argument is required for trackbar creation parameters
def nothing:
	pass
 


def visionCycle(data):
	global bridge
	image = bridge.imgmsg_to_cv2(data, "bgr8")
	hsv=cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
	#read trackbar positions for each trackbar
    hul=cv2.getTrackbarPos(hl, wnd)
    huh=cv2.getTrackbarPos(hh, wnd)
    sal=cv2.getTrackbarPos(sl, wnd)
    sah=cv2.getTrackbarPos(sh, wnd)
    val=cv2.getTrackbarPos(vl, wnd)
    vah=cv2.getTrackbarPos(vh, wnd)
 
    #make array for final values
    HSVLOW=np.array([hul,sal,val])
    HSVHIGH=np.array([huh,sah,vah])
    mask = cv2.inRange(hsv,HSVLOW, HSVHIGH)
    cv2.imshow('mask', mask)
    cv2.waitKey(5)
	pass


print('hi')
	#Capture video from the stream
cv2.namedWindow('Colorbars') 
print('hi')
#assign strings for ease of coding
hh='Hue High'
hl='Hue Low'
sh='Saturation High'
sl='Saturation Low'
vh='Value High'
vl='Value Low'
wnd = 'Colorbars'
#Begin Creating trackbars for each
cv2.createTrackbar(hl, wnd,0,179,nothing)
cv2.createTrackbar(hh, wnd,0,179,nothing)
cv2.createTrackbar(sl, wnd,0,255,nothing)
cv2.createTrackbar(sh, wnd,0,255,nothing)
cv2.createTrackbar(vl, wnd,0,255,nothing)
cv2.createTrackbar(vh, wnd,0,255,nothing) 
print('created')
bridge = CvBridge()
rospy.init_node('bebop_trackbar')
subVideo = rospy.Subscriber('/bebop/image_raw', Image, visionCycle)
rospy.spin()