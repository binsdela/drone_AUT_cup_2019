#!/usr/bin/env python

# The Keyboard Controller Node for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials

# This controller extends the base DroneVideoDisplay class, adding a keypress handler to enable keyboard control of the drone

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib
import rospy
import time
import numpy as np
import cv2
import cv2 as cv

#*********************************************************************************************************
from simple_pid import PID
pid_YAW=PID(1,0.0,0.0,setpoint=0,output_limits=(-0.5, +0.5))
pid_ROLL=PID(1,0,0.0,setpoint=0,output_limits=(-0.5, +0.5))
# Load the DroneController class, which handles interactions with the drone, and the DroneVideoDisplay class, which handles video display
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import CompressedImage
from geometry_msgs.msg import Twist
#Line_detection_object=None
# We add a keyboard handler to the DroneVideoDisplay to react to keypresses
class Line_detection:
	def __init__(self):
		self.calibrate=True
		self.firsttime=True
#***********************************************************************************************
		self.bridge = CvBridge()
		self.subVideo = rospy.Subscriber('/bebop/image_raw/compressed', CompressedImage, self.visionCycle)
		self.cutwidth=50
		self.flag_perspective=False
#**********************************************************************************************
		self.running =rospy.get_param("F_running")
		self.max_speed_go=rospy.get_param("maxspeed_go")
		self.bound=0.3
		self.boundp=rospy.get_param("boundp")
		pid_YAW.Kp=rospy.get_param("P_YAW")
		pid_YAW.Kd=rospy.get_param("D_YAW")
		pid_YAW.Ki=rospy.get_param("I_YAW")
		pid_ROLL.Kp=rospy.get_param("P_ROLL")
		pid_ROLL.Kp=rospy.get_param("D_ROLL")
		pid_ROLL.Kp=rospy.get_param("I_ROLL")
		self.printing=True
		self.pub = rospy.Publisher('Send_yaw_roll_controller_out', Twist, queue_size=10)
		self.command=Twist()
		#**********************************************************************************************
		rospy.spin()
#******************************************************************************************************************
	def nothing(self,a):
		pass
#******	************************************************************************************************
	def Getrosparam(self):
		self.running =rospy.get_param("F_running")
		self.max_speed_go=rospy.get_param("maxspeed_go")
		self.boundp=rospy.get_param("boundp")
		pid_YAW.Kp=rospy.get_param("P_YAW")
		pid_YAW.Kd=rospy.get_param("D_YAW")
		#pid_YAW.Ki=rospy.get_param("I_YAW")
		pid_ROLL.Kp=rospy.get_param("P_ROLL")
		pid_ROLL.Kp=rospy.get_param("D_ROLL")
		#pid_ROLL.Kp=rospy.get_param("I_ROLL")
		self.bound=rospy.get_param("boundY")
		pid_YAW.output_limits=(-1*(self.bound),self.bound)
		self.bound=rospy.get_param("boundR")
		pid_ROLL.output_limits=(-1*(self.bound),self.bound)
#****************************************************************************************************
	def visionCycle(self, data):
		try:
    			cv_image = self.bridge.compressed_imgmsg_to_cv2(data, "bgr8")
       		except CvBridgeError as e:
          		print(e)
		(hh,ww,channels) = cv_image.shape
#***************************************************************************************************
		if(self.firsttime==True):
			h_low = 0
        		s_low = 0
       			v_low = 0
    			h_high =0
    			s_high =0
        		v_high =0	
			self.firsttime=False	
			if (self.calibrate==True):
	       			cv2.imshow('Trackbar Line', np.zeros((1, 512, 3), np.uint8))
				cv2.namedWindow('Trackbar Line')
	       			# create trackbars for color change		
	       			cv2.createTrackbar('H_high', 'Trackbar Line', 0, 255, self.nothing)
	       			cv2.createTrackbar('S_high', 'Trackbar Line', 0, 255, self.nothing)
	       			cv2.createTrackbar('V_high', 'Trackbar Line', 0, 255,self.nothing)
				cv2.createTrackbar('H_low', 'Trackbar Line', 0, 255, self.nothing)
				cv2.createTrackbar('S_low', 'Trackbar Line', 0, 255, self.nothing)
				cv2.createTrackbar('V_low', 'Trackbar Line', 0, 255, self.nothing)
				cv2.waitKey(10)	#//////////////////////////////////////////////////////////////////////////////////////////////////////////
				fh = open("/home/avjf/ali_ros_projects/src/bebop/src/line_color_calibrate.txt", "r")
				self.HIGH=[0,0,0]
				self.LOW=[0,0,0]
				i=0
				data=fh.readlines()
				for line in data:
    					if(i<=2):
        					self.LOW[i]=int(line)
    					else:
        					self.HIGH[i-3]=int(line)
    					i=i+1
				fh.close()
				if (self.calibrate==True):
					cv2.setTrackbarPos('H_high', 'Trackbar Line',self. HIGH[0])
					cv2.setTrackbarPos('S_high', 'Trackbar Line',self. HIGH[1])
	    				cv2.setTrackbarPos('V_high', 'Trackbar Line', self.HIGH[2])
					cv2.setTrackbarPos('H_low', 'Trackbar Line',self. LOW[0])
					cv2.setTrackbarPos('S_low', 'Trackbar Line', self.LOW[1])
					cv2.setTrackbarPos('V_low', 'Trackbar Line', self.LOW[2])
#****************************************************************************************************
		cameramtx=np.array([[534.757567, 0.000000, 424.853015],[0.000000, 525.572232, 240.280387],[0.000000, 0.000000, 1.000000]])
		dismtx= np.array([0.002639, -0.000265, -0.000412, -0.004122, 0.000000])
		newcameramtx, roi=cv2.getOptimalNewCameraMatrix(cameramtx,dismtx,(ww,hh),1,(ww,hh))
		cv_image = cv2.undistort(cv_image, cameramtx, dismtx, None, newcameramtx)
		x,y,w,h = roi
		cv_image = cv_image[y:y+h, x:x+w]
		mapx,mapy = cv2.initUndistortRectifyMap(cameramtx,dismtx,None,newcameramtx,(w,h),5)
		cv_image = cv2.remap(cv_image,mapx,mapy,cv2.INTER_LINEAR)		
		x,y,w,h = roi
		cv_image = cv_image[y:y+h, x:x+w]
		
#*****************************************************************************************************
		pts1 = np.float32([[346,480],[477,480],[400,0],[450,0]])
		pts2 = np.float32([[346,480],[477,480],[353,0],[467,0]])
		M = cv2.getPerspectiveTransform(pts1,pts2)
		line_image = cv2.warpPerspective(cv_image,M,(ww,hh))
#*****************************************************************************************************

		hsvButtom = line_image[hh-self.cutwidth:hh, :]
		hsvTop = line_image[0:self.cutwidth, :]
		hsvLeft = line_image[:, 0:self.cutwidth]
		hsvRight = line_image[:, ww-self.cutwidth:ww]

		hsvButtom = cv2.GaussianBlur(hsvButtom,(5,5),0)
		hsvTop = cv2.GaussianBlur(hsvTop,(5,5),0)
		hsvLeft = cv2.GaussianBlur(hsvLeft,(5,5),0)
		hsvRight = cv2.GaussianBlur(hsvRight,(5,5),0)

		hsvButtom = cv2.cvtColor(hsvButtom, cv2.COLOR_RGB2HSV)
		hsvTop = cv2.cvtColor(hsvTop, cv2.COLOR_RGB2HSV)
		hsvLeft = cv2.cvtColor(hsvLeft, cv2.COLOR_RGB2HSV)
		hsvRight = cv2.cvtColor(hsvRight, cv2.COLOR_RGB2HSV)
#/////////////////////////////////////////////////////////////////////////////////////////
		if(self.calibrate==True):
       			h_low = cv2.getTrackbarPos('H_low', 'Trackbar Line')
        		s_low = cv2.getTrackbarPos('S_low', 'Trackbar Line')
       			v_low = cv2.getTrackbarPos('V_low', 'Trackbar Line')
    			h_high = cv2.getTrackbarPos('H_high', 'Trackbar Line')
    			s_high = cv2.getTrackbarPos('S_high', 'Trackbar Line')
        		v_high = cv2.getTrackbarPos('V_high', 'Trackbar Line')
			fh = open("/home/avjf/ali_ros_projects/src/bebop/src/line_color_calibrate.txt", "w")
			fh.write(str(h_low))
			fh.write("\n"+str(s_low))
			fh.write("\n"+str(v_low))
			fh.write("\n"+str(h_high))
			fh.write("\n"+str(s_high))
			fh.write("\n"+str(v_high))
			fh.close()	
#/////////////////////////////////////////////////////////////////////////////////////////////////////
		else:
       			h_low = self.LOW[0]
        		s_low = self.LOW[1]
       			v_low = self.LOW[2]
    			h_high = self.HIGH[0]
    			s_high = self.HIGH[2]
        		v_high =self.HIGH[2]		

#//////////////////////////////////////////////////////////////////////////////////////
		lower = np.array([h_low,s_low,v_low])#[112,93,0])
		upper = np.array([h_high,s_high,v_high])#123 ,214,255])
#///////////////////////////////////////////////////////////////////////////////////////////////	
		hsvButtom = cv2.inRange(hsvButtom, lower, upper)
		hsvTop = cv2.inRange(hsvTop, lower, upper)
		hsvLeft = cv2.inRange(hsvLeft, lower, upper)
		hsvRight = cv2.inRange(hsvRight, lower, upper)
#///////////////////////////////////////////////////////////////////////////////////////////////////
		if(self.calibrate==True):
			cv2.imshow('top', hsvTop)
			cv2.imshow('buttom', hsvButtom)
			cv2.imshow('left', hsvLeft)
			cv2.imshow('right', hsvRight)
			cv2.waitKey(1)		
#*****************************************************************************************************
		hsvButtom, contoursB, hierarchyB = cv2.findContours(hsvButtom, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		hsvTop, contoursT, hierarchyT = cv2.findContours(hsvTop, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		hsvLeft, contoursL, hierarchyL = cv2.findContours(hsvLeft, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		hsvRight, contoursR, hierarchyR = cv2.findContours(hsvRight, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		

		maxContours = []
		maxContours.append( self.findMaxContour(contoursB,0) )
		maxContours.append( self.findMaxContour(contoursT,1) )
		maxContours.append( self.findMaxContour(contoursL,2) )
		maxContours.append( self.findMaxContour(contoursR,3) )

		maxContours[0][1] += hh-self.cutwidth 			# shifting y to match camera frame
		maxContours[3][0] += ww-self.cutwidth			# shifting x to match camera frame
	#*****************************************************************************************************

		maxNum = -1
		maxArea = 0
		drawLine = False
		for i in range(0,4):
			if maxContours[i][2] > maxArea :
				maxArea = maxContours[i][2]
				maxNum = i
		
		if maxNum != -1 :
			firstContour = maxContours[maxNum]
			maxContours.pop(maxNum)

			maxArea = 0
			maxNum = -1
		for i in range(0,3):
			if maxContours[i][2] > maxArea :
				maxArea = maxContours[i][2]
				maxNum = i

		if maxNum != -1 :
			secondContour = maxContours[maxNum]
			drawLine = True
			#print (maxArea)
		
	#*****************************************************************************************************
		lineAngle=0
		lineDeviation=0
		if drawLine :
			print('line yes')
			cv2.line(line_image, (firstContour[0], firstContour[1]), (secondContour[0], secondContour[1]), (255, 0, 0), 5)
			lineDeviation = (float((firstContour[0]+secondContour[0])/2)- ww/2) * -0.001   #deviation from center line
			if firstContour[1]-secondContour[1]!=0:
				lineAngle = np.arctan(float(firstContour[0]-secondContour[0]) / float(firstContour[1]-secondContour[1]))
				if self.printing is True :
					print("line deviation is: " + str(lineDeviation)+"  line angel is: " + str(lineAngle))				
			self.controll_move(lineAngle, lineDeviation)
			
#*******************************************************************************************************************************************	
#*****************************************************************************************************

		if(self.calibrate==False):
			cv2.imshow('line image',line_image)
			cv2.waitKey(1)
#*****************************************************************************************************
	def findMaxContour(self, contours,id):
		if len(contours) > 0 :
			cnt = max(contours, key = cv2.contourArea)
			M = cv2.moments(cnt)
			if M['m00'] != 0:
				cx = int(M['m10']/M['m00'])
				cy = int(M['m01']/M['m00'])
				return [cx, cy, cv2.contourArea(cnt),id]
			else :
				return [0, 0, 0,-1]
				
		else :
			return [0, 0, 0,-1]
#*****************************************************************************************************
	def controll_move(self,lineAngle,lineDeviation):
		PITCH_out=0	
		self.Getrosparam()
		ROLL_out=pid_ROLL(-1*lineDeviation)
		YAW_out=pid_YAW(-1*(lineAngle))
		self.command.angular.y=ROLL_out
		self.command.linear.z=YAW_out
#////////////////////////////////////////////////////////////////////////////////////////////////
		if np.absolute(lineAngle) < self.boundp:
			PITCH_out=self.max_speed_go
		elif PITCH_out>(self.max_speed_go/3):
			if self.running is True :
				#self.command.z=0
				self.command.angular.z=YAW_out
				self.command.angular.y=ROLL_out
				self.command.angular.y=-PITCH_out
				self.pub.publish(self.command)
			PITCH_out=self.max_speed_go/3
		if PITCH_out<0:
			PITCH_out=0
#/////////////////////////////////////////////////////////////////////////////////////////////////
		if self.printing is True :
			print("  yaw_out: "+str(YAW_out)+"  ROLL_out: "+str(ROLL_out)+"  PITCH_out: "+str(PITCH_out))
		if self.running is True :
			self.command.linear.z=0
			self.command.angular.z=YAW_out
			self.command.angular.y=ROLL_out
			self.command.angular.y=PITCH_out
			self.pub.publish(self.command)
#***************************************************************************************************************

# Setup the application
if __name__=='__main__':
	rospy.init_node('Line_1')
	Line_detection_object=Line_detection()
	#rospy.signal_shutdown('Great Flying!')
	

