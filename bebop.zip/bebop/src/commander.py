#!/usr/bin/env python

# The Keyboard Controller Node for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials

# This controller extends the base DroneVideoDisplay class, adding a keypress handler to enable keyboard control of the drone

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib
import rospy
import time
import numpy as np
import cv2
import cv2 as cv
#*********************************************************************************************************
#*****************************************************************************************************************
# Load the DroneController class, which handles interactions with the drone, and the DroneVideoDisplay class, which handles video display
from drone_controller import BasicDroneController
from bebop_msgs.msg import CommonCommonStateBatteryStateChanged as Batt
from bebop_msgs.msg import Ardrone3PilotingStateAltitudeChanged as hight
from geometry_msgs.msg import Twist

class commander():
	def __init__(self):
		self.bound=0.3
#-----/////////////////////////////////////////////////////////////--------------------------------------------------
		self.kEYBOARD = rospy.Subscriber('/Send_Key_board_controller_out',Twist,self.KeyBoard)
		self.keyboardcontrol=Twist()
		self.keyboardflag=True
#//////////////////////////////////////////////////////////////////////////////////////////////////
		self.LINE = rospy.Subscriber('/Send_yaw_roll_controller_out',Twist,self.Line)
		self.linecontrol=Twist()
		self.lineflag=False
#/////////////////////////////////////////////////////////////////////////////////////////////////////////
		self.CIRCLE = rospy.Subscriber('/Send_X_Z_controller_out',Twist,self.Circle)
		self.windowcontrol=Twist()
		self.cirlcleflag=False
#/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		self.Hight = rospy.Subscriber('/bebop/states/ardrone3/PilotingState/AltitudeChanged',hight,self.get_hight)
#//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		self.subBatt = rospy.Subscriber('/bebop/states/common/CommonState/BatteryStateChanged', Batt, self.battCheck)
#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		self.commandparam=Twist()
		self.command= BasicDroneController()
		while not rospy.is_shutdown():
			self.Getrosparam()
			if (self.keyboardflag==True):
				self.commandparam=self.keyboardcontrol
			elif (self.lineflag==True) & (self.running==True):
				self.commandparam=self.linecontrol
			elif (self.cirlcleflag==True) & (self.running==True):
				self.commandparam=self.windowcontrol
			else :
				self.commandparam=0

				self.command.SetCommand(self.commandparam.angular.y,self.commandparam.angular.x,self.commandparam.angular.z,self.commandparam.linear.z)
#***************************************************************************************************
	def KeyBoard(self,data):
		self.keyboardflag=True
		self.keyboardcontrol=data


#****************************************************************************************************
#***************************************************************************************************
	def Line(self,data):
		self.lineflag=True
		self.linecontrol=data

#****************************************************************************************************
#***************************************************************************************************
	def Circle(self,data):
		self.cirlcleflag=True
		self.windowcontrol=data


#****************************************************************************************************
#***************************************************************************************************
	def get_hight(self,data):
		self.HIGHT=data.altitude*100

#****************************************************************************************************
	def battCheck(slef,data):
		print data
#****************************************************************************************************
	def Getrosparam(self):
		self.running = rospy.get_param("F_running")
		self.max_speed_go=rospy.get_param("maxspeed_go")

#****************************************************************************************************
# Setup the application
if __name__=='__main__':
	rospy.init_node('commander_1',disable_signals=True)
	com=commander()
