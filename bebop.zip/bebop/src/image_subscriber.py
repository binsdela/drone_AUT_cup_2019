#!/usr/bin/env python

import rospy
import time
import numpy as np
import cv2


  from cv_bridge import CvBridge, CvBridgeError
  from sensor_msgs.msg import Image



def visionCycle(data):
    rospy.loginfo("Subscrib Image")
    try:
		cv_image = bridge.imgmsg_to_cv2(data, "bgr8")
    except CvBridgeError as e:
		print(e)
    cv2.imshow('top', cv_image)
    cv2.waitKey(5)


def listener():
    rospy.init_node('cv_camera',anonymous=True, disable_signals=True)
    subVideo = rospy.Subscriber('/tello/image_raw', Image, visionCycle)
    rospy.spin()


if __name__=='__main__':
    rospy.loginfo('init ...')
    bridge = CvBridge()
    listener()
        
