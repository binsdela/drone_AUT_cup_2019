import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image



def talker():
    pub=rospy.Publisher('camerasend',Image,queue_size=10)

    rospy.init_node('camerasender', anonymous=True)
    rate=rospy.Rate(10)
    while not rospy.is_shutdown():
        ret,Image=a.read()
        pub.publish(Image)
        rate.sleep()

if __name__='__main__':
    a=cv2.VideoCapture(-1)
    try :
        talker()
    except:
        pass
        