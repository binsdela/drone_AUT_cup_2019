#!/usr/bin/env python

# The Keyboard Controller Node for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials

# This controller extends the base DroneVideoDisplay class, adding a keypress handler to enable keyboard control of the drone

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib
import rospy
import time
import numpy as np
import cv2
import cv2 as cv

#*********************************************************************************************************
from simple_pid import PID
pid_YAW=PID(0.0,0.0,0.0,setpoint=0,output_limits=(-0.5, +0.5))
pid_ROLL=PID(0.0,0,0.0,setpoint=0,output_limits=(-0.5, +0.5))
pid_Z=PID(0.0,0,0.0,setpoint=0,output_limits=(-0.5, +0.5))  #0.1  0.05##0.3,0.2
pid_X=PID(0.0,0,0.0,setpoint=0,output_limits=(-0.5, +0.5))  #0.1  0.05##0.3,0.2
#*****************************************************************************************************************
# Load the DroneController class, which handles interactions with the drone, and the DroneVideoDisplay class, which handles video display
from drone_controller import BasicDroneController
from drone_video_display import DroneVideoDisplay

from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import CompressedImage
from bebop_msgs.msg import CommonCommonStateBatteryStateChanged as Batt
from bebop_msgs.msg import Ardrone3PilotingStateAltitudeChanged as hight
from geometry_msgs.msg import Twist

# Finally the GUI libraries
from PyQt5 import QtCore, QtGui, QtWidgets


# Here we define the keyboard map for our controller (note that python has no enums, so we use a class)
class KeyMapping(object):
	PitchForward     = QtCore.Qt.Key_W
	PitchBackward    = QtCore.Qt.Key_S
	RollLeft         = QtCore.Qt.Key_A
	RollRight        = QtCore.Qt.Key_D
	YawLeft          = QtCore.Qt.Key_Q
	YawRight         = QtCore.Qt.Key_E
	IncreaseAltitude = QtCore.Qt.Key_I
	DecreaseAltitude = QtCore.Qt.Key_K
	Takeoff          = QtCore.Qt.Key_T
	Land             = QtCore.Qt.Key_Space
	Emergency        = QtCore.Qt.Key_Enter
	StartStop        = QtCore.Qt.Key_O
	CameraUp	 = QtCore.Qt.Key_2
	CameraDown	 = QtCore.Qt.Key_1
	IncreaseP	 = QtCore.Qt.Key_P
	DecreaseP	 = QtCore.Qt.Key_L
	IncreaseD	 = QtCore.Qt.Key_J
	DecreaseD	 = QtCore.Qt.Key_H
	IncreaseBoundP	 = QtCore.Qt.Key_U
	DecreaseBoundP	 = QtCore.Qt.Key_Y
	IncreaseSaturation=QtCore.Qt.Key_M
	DecreaseSaturation=QtCore.Qt.Key_N
	IncreaseMAXSpeed= QtCore.Qt.Key_X
	DecreaseMAXSpeed= QtCore.Qt.Key_Z
	CloseApp	 =QtCore.Qt.Key_Escape

# Our controller definition, note that we extend the DroneVideoDisplay class
class KeyboardController(DroneVideoDisplay):
	def __init__(self):
		super(KeyboardController,self).__init__()
		self.pubCamera = rospy.Publisher('/bebop/camera_control', Twist, queue_size=1)
		time.sleep(1)
		print('init ... ')
		self.cameraCommand = Twist()
		self.cameraCommand.angular.z = 0
		self.cameraCommand.angular.y = -45
		self.pubCamera.publish(self.cameraCommand)
#***********************************************************************************************
		self.controller=BasicDroneController()
		self.pitch = 0
		self.roll = 0
		self.yaw_velocity = 0 
		self.z_velocity = 0
		self.command=Twist()
#///////////////////////////////////////////////////////////////////////////////////////////////
		self.running = False
		self.bound=0.2
		self.max_speed_go=0.1
		self.boundp=0.1
		self.ya=False
		self.rol=False
		self.Z=False
		self.X=True
		self.printing=True
		self.pub = rospy.Publisher('Send_Key_board_controller_out', Twist, queue_size=10)
# We add a keyboard handler to the DroneVideoDisplay to react to keypresses
	def keyPressEvent(self, event):
		key = event.key()
		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if True:
			# Handle the important cases first!
			if key == KeyMapping.Emergency:
				self.controller.SendEmergency()

			elif key == KeyMapping.CloseApp:
				self.controller.SendLand()
				cv2.destroyAllWindows()
				print ("BB")
				self.close()
			elif key == KeyMapping.CameraDown : 
				self.cameraCommand.angular.z = 0
				self.cameraCommand.angular.y += -5
				if self.cameraCommand.angular.y < -80:
					self.cameraCommand.angular.y = -80
				self.pubCamera.publish(self.cameraCommand)
			elif key == KeyMapping.CameraUp : 
				self.cameraCommand.angular.z = 0
				self.cameraCommand.angular.y += 5
				if self.cameraCommand.angular.y > 15:
					self.cameraCommand.angular.y = 15
				self.pubCamera.publish(self.cameraCommand)
			elif key == KeyMapping.Takeoff:
				self.controller.SendTakeoff()
			elif key == KeyMapping.Land:
				self.controller.SendLand()

			elif self.running is False and key == KeyMapping.StartStop :
				print('Starting ...')
				self.running = True
				rospy.set_param=("F_running",self.running)
			elif key == KeyMapping.StartStop :
				print('Stopping ...')
				self.running = False
				rospy.set_param=("F_running",self.running)
#*****************************************************************************************************

			else:
				# Now we handle moving, notice that this section is the opposite (+=) of the keyrelease section
				if key == KeyMapping.YawLeft:
					self.yaw_velocity += 0.3
				elif key == KeyMapping.YawRight:
					self.yaw_velocity += -0.3

				elif key == KeyMapping.PitchForward:
					self.pitch += 0.3
				elif key == KeyMapping.PitchBackward:
					self.pitch += -0.3

				elif key == KeyMapping.RollLeft:
					self.roll += 0.3
				elif key == KeyMapping.RollRight:
					self.roll += -0.3

				elif key == KeyMapping.IncreaseAltitude:
					self.z_velocity += 0.3
				elif key == KeyMapping.DecreaseAltitude:
					self.z_velocity += -0.3
#********************************************************************************************************
				elif key == KeyMapping.IncreaseP:
					if(self.ya==True):
						pid_YAW.Kp+=0.05
						rospy.set_param("P_YAW",pid_YAW.Kp)
						print ("PID: p: "+str(pid_YAW.Kp)+" :D "+str(pid_YAW.Kd)+" :I "+str(pid_YAW.Ki))
					if(self.rol==True):
						pid_ROLL.Kp+=0.05
						rospy.set_param("P_ROLL",pid_ROLL.Kp)
						print ("PID: p: "+str(pid_ROLL.Kp)+" :D "+str(pid_ROLL.Kd)+" :I "+str(pid_ROLL.Ki))
					if(self.Z==True):
						pid_Z.Kp+=0.05
						rospy.set_param("P_Z",pid_Z.Kp)
						print ("PID: p: "+str(pid_Z.Kp)+" :D "+str(pid_Z.Kd)+" :I "+str(pid_Z.Ki))
					if(self.X==True):
						pid_X.Kp+=0.05	
						rospy.set_param("P_X",pid_X.Kp)
						print ("PID: p: "+str(pid_X.Kp)+" :D "+str(pid_X.Kd)+" :I "+str(pid_X.Ki))				
					self.printing=False

				elif key == KeyMapping.DecreaseP:
					if(self.ya==True):
						pid_YAW.Kp-=0.05
						if pid_YAW.Kp <0:
							pid_YAW.Kp=0
							rospy.set_param("P_YAW",pid_YAW.Kp)
						print ("PID: p: "+str(pid_YAW.Kp)+" :D "+str(pid_YAW.Kd)+" :I "+str(pid_YAW.Ki))
					if(self.rol==True):
						pid_ROLL.Kp-=0.05
						if pid_ROLL.Kp <0:
							pid_ROLL.Kp=0
							rospy.set_param("P_ROLL",pid_ROLL.Kp)
						print ("PID: p: "+str(pid_ROLL.Kp)+" :D "+str(pid_ROLL.Kd)+" :I "+str(pid_ROLL.Ki))

					if(self.Z==True):
						pid_Z.Kp-=0.05
						if pid_Z.Kp <0:
							pid_Z.Kp=0
							rospy.set_param("P_Z",pid_Z.Kp)
						print ("PID: p: "+str(pid_Z.Kp)+" :D "+str(pid_Z.Kd)+" :I "+str(pid_Z.Ki))

					if(self.X==True):
						pid_X.Kp-=0.05
						if pid_X.Kp <0:
							pid_X.Kp=0
							rospy.set_param("P_X",pid_X.Kp)
						print ("PID: p: "+str(pid_X.Kp)+" :D "+str(pid_X.Kd)+" :I "+str(pid_X.Ki))

					self.printing=False
					
		
#//////////////////////////////////////////////////////////////////////////////////////////////////////
				elif key == KeyMapping.IncreaseD:
					if(self.ya==True):
						pid_YAW.Kd+=0.05
						rospy.set_param("P_YAW",pid_YAW.Kd)
						print ("PID: p: "+str(pid_YAW.Kp)+" :D "+str(pid_YAW.Kd)+" :I "+str(pid_YAW.Ki))
					if(self.rol==True):
						pid_ROLL.Kd+=0.05
						rospy.set_param("P_ROLL",pid_ROLL.Kd)
						print ("PID: p: "+str(pid_ROLL.Kp)+" :D "+str(pid_ROLL.Kd)+" :I "+str(pid_ROLL.Ki))
					if(self.Z==True):
						pid_Z.Kd+=0.05
						rospy.set_param("P_Z",pid_Z.Kd)
						print ("PID: p: "+str(pid_Z.Kp)+" :D "+str(pid_Z.Kd)+" :I "+str(pid_Z.Ki))
					if(self.X==True):
						pid_X.Kd+=0.05	
						rospy.set_param("P_X",pid_X.Kd)
						print ("PID: p: "+str(pid_X.Kp)+" :D "+str(pid_X.Kd)+" :I "+str(pid_X.Ki))				
					self.printing=False

				elif key == KeyMapping.DecreaseD:
					if(self.ya==True):
						pid_YAW.Kd-=0.05
						if pid_YAW.Kd <0:
							pid_YAW.Kd=0
							rospy.set_param("P_YAW",pid_YAW.Kd)
						print ("PID: p: "+str(pid_YAW.Kp)+" :D "+str(pid_YAW.Kd)+" :I "+str(pid_YAW.Ki))
					if(self.rol==True):
						pid_ROLL.Kd-=0.05
						if pid_ROLL.Kd <0:
							pid_ROLL.Kd=0
							rospy.set_param("P_ROLL",pid_ROLL.Kd)
						print ("PID: p: "+str(pid_ROLL.Kp)+" :D "+str(pid_ROLL.Kd)+" :I "+str(pid_ROLL.Ki))

					if(self.Z==True):
						pid_Z.Kd-=0.05
						if pid_Z.Kd <0:
							pid_Z.Kd=0
							rospy.set_param("P_Z",pid_Z.Kd)
						print ("PID: p: "+str(pid_Z.Kp)+" :D "+str(pid_Z.Kd)+" :I "+str(pid_Z.Ki))

					if(self.X==True):
						pid_X.Kd-=0.05
						if pid_X.Kd <0:
							pid_X.Kd=0
							rospy.set_param("P_X",pid_X.Kd)
						print ("PID: p: "+str(pid_X.Kp)+" :D "+str(pid_X.Kd)+" :I "+str(pid_X.Ki))

					self.printing=False
#/////////////////////////////////////////////////////////////////////////////////////////////////////	
				elif key == KeyMapping.IncreaseBoundP:
					self.boundp+=0.05
					self.printing=False
					print("boundp: "+str(self.boundp))
				elif key == KeyMapping.DecreaseBoundP:
					self.boundp-=0.05
					if self.boundp <0:
						self.boundp=0
					self.printing=False
					print("boundp: "+str(self.boundp))
#/////////////////////////////////////////////////////////////////////////////////////////////////////
				elif key == KeyMapping.IncreaseSaturation:
					self.bound+=0.05
					if(self.ya==True):
						pid_YAW.output_limits=(-self.bound,self.bound)
						rospy.set_param("boundY",self.bound)
						print (str(pid_YAW.output_limits))
					if(self.rol==True):
						pid_ROLL.output_limits=(-self.bound,self.bound)
						rospy.set_param("boundR",self.bound)
						print (str(pid_ROLL.output_limits))
					if(self.Z==True):
						pid_Z.output_limits=(-self.bound,self.bound)
						rospy.set_param("boundZ",self.bound)
						print (str(pid_Z.output_limits))
					if(self.X==True):
						pid_X.output_limits=(-self.bound,self.bound)
						rospy.set_param("boundX",self.bound)
						print (str(pid_X.output_limits))
					self.printing=False
				elif key == KeyMapping.DecreaseSaturation:
					self.bound-=0.05
					if self.bound <0:
						self.bound=0
					if(self.ya==True):
						pid_YAW.output_limits=(-self.bound,self.bound)
						rospy.set_param("boundY",self.bound)
						print (str(pid_YAW.output_limits))
					if(self.rol==True):
						pid_ROLL.output_limits=(-self.bound,self.bound)
						rospy.set_param("boundR",self.bound)
						print (str(pid_ROLL.output_limits))
					if(self.Z==True):
						pid_Z.output_limits=(-self.bound,self.bound)
						rospy.set_param("boundZ",self.bound)
						print (str(pid_Z.output_limits))
					if(self.X==True):
						pid_X.output_limits=(-self.bound,self.bound)
						rospy.set_param("boundX",self.bound)
						print (str(pid_X.output_limits))
					self.printing=False
#/////////////////////////////////////////////////////////////////////////////////////////////////////
				elif key == KeyMapping.IncreaseMAXSpeed:
					self.max_speed_go+=0.05
					rospy.set_param("maxspeed_go",self.max_speed_go)
					print ("maxspeed : "+str(self.max_speed_go))
				elif key == KeyMapping.DecreaseMAXSpeed:
					self.max_speed_go-=0.05
					if self.max_speed_go <0:
						self.max_speed_go=0;
					rospy.set_param("maxspeed_go",self.max_speed_go)
					self.printing=False
					print ("maxspeed : "+str(self.max_speed_go))
					self.printing=False
#/////////////////////////////////////////////////////////////////////////////////////////////////////
			# finally we set the command to be sent. The controller handles sending this at regular intervals

			self.command.angular.z=self.yaw_velocity
			self.command.angular.y=self.roll
			self.command.angular.x=self.pitch
			self.command.linear.x=self.z_velocity 
			self.pub.publish(self.command)
#******************************************************************************************************
	def battCheck ( self , Bdata):
		print(Bdata)

	def keyReleaseEvent(self,event):
		key = event.key()

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if True:
			# Note that we don't handle the release of emergency/takeoff/landing keys here, there is no need.
			# Now we handle moving, notice that this section is the opposite (-=) of the keypress section
			if key == KeyMapping.YawLeft:
				self.yaw_velocity -= 0.3
			elif key == KeyMapping.YawRight:
				self.yaw_velocity -= -0.3

			elif key == KeyMapping.PitchForward:
				self.pitch -= 0.3
			elif key == KeyMapping.PitchBackward:
				self.pitch -= -0.3

			elif key == KeyMapping.RollLeft:
				self.roll -= 0.3
			elif key == KeyMapping.RollRight:
				self.roll -= -0.3

			elif key == KeyMapping.IncreaseAltitude:
				self.z_velocity -= 0.3
			elif key == KeyMapping.DecreaseAltitude:
				self.z_velocity -= -0.3
			else:
#********************************************************************************************************
				if key == KeyMapping.IncreaseP:
					self.printing=True
				elif key == KeyMapping.DecreaseP:
					self.printing=True
#//////////////////////////////////////////////////////////////////////////////////////////////////////
				elif key == KeyMapping.IncreaseD:
					self.printing=True
				elif key == KeyMapping.DecreaseD:
					self.printing=True
#/////////////////////////////////////////////////////////////////////////////////////////////////////	
				elif key == KeyMapping.IncreaseBoundP:
					self.printing=True
				elif key == KeyMapping.DecreaseBoundP:
					self.printing=True
#/////////////////////////////////////////////////////////////////////////////////////////////////////
				elif key == KeyMapping.IncreaseSaturation:
					self.printing=True
				elif key == KeyMapping.DecreaseSaturation:
					self.printing=True
#/////////////////////////////////////////////////////////////////////////////////////////////////////
				elif key == KeyMapping.IncreaseMAXSpeed:
					self.printing=True
				elif key == KeyMapping.DecreaseMAXSpeed:
					self.max_speed_go-=0.05
					self.printing=True
#////////////////////////////////////////////////////////////////////////////////////////////////////

			# finally we set the command to be sent. The controller handles sending this at regular intervals
			self.command.angular.z=self.yaw_velocity
			self.command.angular.y=self.roll
			self.command.angular.x=self.pitch
			self.command.linear.x=self.z_velocity 
			self.pub.publish(self.command)
#***************************************************************************************************
#****************************************************************************************************
def Setrosparam_ini():
		rospy.set_param("F_running",0)
		rospy.set_param("maxspeed_go",0)
		rospy.set_param("boundp",0)
		rospy.set_param("P_YAW",1)
		rospy.set_param("D_YAW",0)
		rospy.set_param("I_YAW",0)
		rospy.set_param("P_ROLL",1)
		rospy.set_param("D_ROLL",0)
		rospy.set_param("I_ROLL",0)
		rospy.set_param("boundY",0)
		rospy.set_param("boundR",0)
		rospy.set_param("P_X",100)
		rospy.set_param("D_X",0)
		rospy.set_param("I_X",0)
		rospy.set_param("P_Z",100)
		rospy.set_param("D_Z",0)
		rospy.set_param("I_Z",0)
		rospy.set_param("boundX",0)
		rospy.set_param("boundZ",0)	
#/////////////////////////////////////////////////////////////////////////////////////////////////
#****************************************************************************************************
# Setup the application
if __name__=='__main__':
	Setrosparam_ini()
	import sys
	# Firstly we setup a ros node, so that we can communicate with the other packages
	rospy.init_node('Key_board_1')

	# Now we construct our Qt Application and associated controllers and windows
	app = QtWidgets.QApplication(sys.argv)
	display = KeyboardController()

	display.show()

	# executes the QT application
	status = app.exec_()

	# Doesn't get here!?
	# and only progresses to here once the application has been shutdown
	rospy.signal_shutdown('Great Flying!')

	sys.exit(status)
