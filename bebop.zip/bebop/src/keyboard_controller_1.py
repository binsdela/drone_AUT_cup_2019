#!/usr/bin/env python
import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
import time
from cv_bridge import CvBridge, CvBridgeError

def talker():
	rospy.init_node('camerasender11')	
	pub=rospy.Publisher('camerasend',Image,queue_size=10)
	a=cv2.VideoCapture(-1)
	rate = rospy.Rate(10) # 10hz
	while not rospy.is_shutdown():
		_, b = a.read()
		br=CvBridge()
 		try:
        		k = br.cv2_to_imgmsg(b, 'bgr8')
        		pub.publish(k)
       		except CvBridgeError as e:
        		print (e)
		"""cv2.imshow('a',Image)
		if cv2.waitKey(1)==ord('q'):
			cv2.destroyAllWindows()"""
		rate.sleep()
		rospy.loginfo("Publish Image")



if __name__=='__main__':
    try :
        talker()
    except rospy.ROSInterruptException:
        pass
        
