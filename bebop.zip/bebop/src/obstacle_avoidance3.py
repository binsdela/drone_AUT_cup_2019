#!/usr/bin/env python

# The Keyboard Controller Node for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials

# This controller extends the base DroneVideoDisplay class, adding a keypress handler to enable keyboard control of the drone

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib
import rospy
import time
import numpy as np
import cv2

# Load the DroneController class, which handles interactions with the drone, and the DroneVideoDisplay class, which handles video display
from drone_controller import BasicDroneController
from drone_video_display import DroneVideoDisplay

from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist

# Finally the GUI libraries
from PyQt5 import QtCore, QtGui, QtWidgets


# Here we define the keyboard map for our controller (note that python has no enums, so we use a class)
class KeyMapping(object):
	PitchForward     = QtCore.Qt.Key_W
	PitchBackward    = QtCore.Qt.Key_S
	RollLeft         = QtCore.Qt.Key_A
	RollRight        = QtCore.Qt.Key_D
	YawLeft          = QtCore.Qt.Key_Q
	YawRight         = QtCore.Qt.Key_E
	IncreaseAltitude = QtCore.Qt.Key_I
	DecreaseAltitude = QtCore.Qt.Key_K
	Takeoff          = QtCore.Qt.Key_T
	Land             = QtCore.Qt.Key_Space
	Emergency        = QtCore.Qt.Key_Enter
	StartStop        = QtCore.Qt.Key_Return


# Our controller definition, note that we extend the DroneVideoDisplay class
class KeyboardController(DroneVideoDisplay):
	def __init__(self):
		super(KeyboardController,self).__init__()

		self.controller = BasicDroneController()

		self.bridge = CvBridge()
		self.sequence = [-0.03, 0.03, -0.03, 0.03]

		self.subVideo = rospy.Subscriber('/bebop/image_raw', Image, self.controlCycle)
		
		self.pitch = 0
		self.roll = 0
		self.yaw_velocity = 0 
		self.z_velocity = 0

		self.running = False
		self.row = 0
		self.counter = 51
		self.isHovering = False
		self.forwardCounter = 0
		self.sidewaysCounter = 0
		self.backwardCounter = 0
		self.obstacleInSight = False
		self.oldObstacleInSight = False
		self.obstacleTooNear = False
		self.hoveringTimes = 0
		self.controlAltitude = False

# We add a keyboard handler to the DroneVideoDisplay to react to keypresses
	def keyPressEvent(self, event):
		key = event.key()

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if self.controller is not None and not event.isAutoRepeat():
			# Handle the important cases first!
			if key == KeyMapping.Emergency:
				self.controller.SendEmergency()
			elif key == KeyMapping.Takeoff:
				self.controller.SendTakeoff()
			elif key == KeyMapping.Land:
				self.controller.SendLand()

			elif self.running is False and key == KeyMapping.StartStop :
				print('Starting ...')
				self.running = True
			elif key == KeyMapping.StartStop :
				print('Stopping ...')
				self.running = False

			else:
				# Now we handle moving, notice that this section is the opposite (+=) of the keyrelease section
				if key == KeyMapping.YawLeft:
					self.yaw_velocity += 0.3
				elif key == KeyMapping.YawRight:
					self.yaw_velocity += -0.3

				elif key == KeyMapping.PitchForward:
					self.pitch += 0.3
				elif key == KeyMapping.PitchBackward:
					self.pitch += -0.3

				elif key == KeyMapping.RollLeft:
					self.roll += 0.3
				elif key == KeyMapping.RollRight:
					self.roll += -0.3

				elif key == KeyMapping.IncreaseAltitude:
					self.z_velocity += 0.3
				elif key == KeyMapping.DecreaseAltitude:
					self.z_velocity += -0.3

			# finally we set the command to be sent. The controller handles sending this at regular intervals
			self.controller.SetCommand(self.roll, self.pitch, self.yaw_velocity, self.z_velocity)


	def stopHovering(self, event):
		self.isHovering = False
		self.forwardCounter = 2
		self.sidewaysCounter = 2

	def controlCycle(self, data):
		try:
			cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
		except CvBridgeError as e:
			print(e)
		(rows,cols,channels) = cv_image.shape
		img = cv_image[240:rows, 150:cols-150]

		hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
		lower = np.array([53,188,72])
		upper = np.array([87,256,228])
		mask = cv2.inRange(hsv, lower, upper)
		res = cv2.bitwise_and(img, img, mask= mask)

		grayImage = cv2.cvtColor(res, cv2.COLOR_RGB2GRAY)

		ret, th = cv2.threshold(grayImage, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)

		im2, contours, hierarchy = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		eh = cv2.drawContours(res, contours, -1, (0,255,0), 3)

		self.obstacleTooNear = False
		goodCnts = 0
		for cnt in contours :
			M = cv2.moments(cnt)
			cY = int(M["m01"] / M["m00"])
			area = cv2.contourArea(cnt)
			if area > 80 :
				if cY > 180 :
					self.obstacleTooNear = True
				self.counter = 0
				goodCnts += 1

		self.oldObstacleInSight = self.obstacleInSight
		if goodCnts > 0 :
			self.obstacleInSight = True
		else :
			self.counter += 1
			if self.counter > 50 :
				self.obstacleInSight = False
			else :
				self.obstacleInSight = True

		cv2.imshow('res',eh)
		#cv2.waitKey(33)

		if self.running is True :
			if self.oldObstacleInSight != self.obstacleInSight :
				self.hoveringTimes += 1
				print('Hovering ...')
				self.controller.SetCommand(0, 0, 0, 0)
				self.isHovering = True
				if self.hoveringTimes % 2 == 0 :
					self.row += 1
					print('***** row changed ******')
				rospy.Timer(rospy.Duration(6), self.stopHovering)
			elif self.obstacleTooNear is True :
				self.controller.SetCommand(0, -0.03, 0, 0)
			elif self.obstacleInSight is False and self.isHovering is False and self.obstacleTooNear is False: 
				print('Moving forward ...')
				self.controller.SetCommand(0, 0.03, 0, 0)
			elif self.obstacleInSight is True and self.isHovering is False and self.obstacleTooNear is False :
				print('Moving sideways ...')
				self.controller.SetCommand(0.045, 0, 0, 0)


	def keyReleaseEvent(self,event):
		key = event.key()

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if self.controller is not None and not event.isAutoRepeat():
			# Note that we don't handle the release of emergency/takeoff/landing keys here, there is no need.
			# Now we handle moving, notice that this section is the opposite (-=) of the keypress section
			if key == KeyMapping.YawLeft:
				self.yaw_velocity -= 0.3
			elif key == KeyMapping.YawRight:
				self.yaw_velocity -= -0.3

			elif key == KeyMapping.PitchForward:
				self.pitch -= 0.3
			elif key == KeyMapping.PitchBackward:
				self.pitch -= -0.3

			elif key == KeyMapping.RollLeft:
				self.roll -= 0.3
			elif key == KeyMapping.RollRight:
				self.roll -= -0.3

			elif key == KeyMapping.IncreaseAltitude:
				self.z_velocity -= 0.3
			elif key == KeyMapping.DecreaseAltitude:
				self.z_velocity -= -0.3

			# finally we set the command to be sent. The controller handles sending this at regular intervals
			self.controller.SetCommand(self.roll, self.pitch, self.yaw_velocity, self.z_velocity)



# Setup the application
if __name__=='__main__':
	import sys
	# Firstly we setup a ros node, so that we can communicate with the other packages
	rospy.init_node('bebop_keyboard_controller')
	camPub = rospy.Publisher('/bebop/camera_control', Twist, queue_size=1)

	camTwist = Twist()
    camTwist.linear.x = 0 
	camTwist.linear.y = 0
    camTwist.linear.z = 0
    camTwist.angular.x = 0
    camTwist.angular.y = -45
    camTwist.angular.z = 0
    camPub.publish(camTwist)

	# Now we construct our Qt Application and associated controllers and windows
	app = QtWidgets.QApplication(sys.argv)
	display = KeyboardController()

	display.show()

	# executes the QT application
	status = app.exec_()

	# and only progresses to here once the application has been shutdown
	rospy.signal_shutdown('Great Flying!')
	sys.exit(status)
